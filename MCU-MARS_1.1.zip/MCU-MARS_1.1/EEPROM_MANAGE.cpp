#include "EEPROM_MANAGE.h"

// ---- 全域變數的唯一定義（可給初值）----
int EEPROM_Parameter_exist = 0;

// Output configuration
int EEPROM_BAUDRATE = 0;
int EEPROM_DATARATE = 0;
int EEPROM_SYSCLK   = 0;
int EEPROM_EXTWDT   = 0;

// Misalignment calibration
int EEPROM_CALI_AX = 0, EEPROM_CALI_AY = 0, EEPROM_CALI_AZ = 0;
int EEPROM_CALI_A11 = 0, EEPROM_CALI_A12 = 0, EEPROM_CALI_A13 = 0;
int EEPROM_CALI_A21 = 0, EEPROM_CALI_A22 = 0, EEPROM_CALI_A23 = 0;
int EEPROM_CALI_A31 = 0, EEPROM_CALI_A32 = 0, EEPROM_CALI_A33 = 0;
int EEPROM_CALI_GX = 0, EEPROM_CALI_GY = 0, EEPROM_CALI_GZ = 0;
int EEPROM_CALI_G11 = 0, EEPROM_CALI_G12 = 0, EEPROM_CALI_G13 = 0;
int EEPROM_CALI_G21 = 0, EEPROM_CALI_G22 = 0, EEPROM_CALI_G23 = 0;
int EEPROM_CALI_G31 = 0, EEPROM_CALI_G32 = 0, EEPROM_CALI_G33 = 0;

// Attitude filter
int EEPROM_THRESHOLD_WX = 0, EEPROM_THRESHOLD_WY = 0, EEPROM_THRESHOLD_WZ = 0;

// ---- 物件的唯一定義 ----
eeprom_obj eeprom_x(EEPROM_BASEADDR_X);
eeprom_obj eeprom_y(EEPROM_BASEADDR_Y);
eeprom_obj eeprom_z(EEPROM_BASEADDR_Z);

#ifndef COMMON_H
#define COMMON_H

#include <Arduino.h>
#include <stdint.h>
#include <stddef.h>
#include <stdarg.h>
#include "domain/model/memory_manage.h"
#include "utils/serial_printf.h"
#include "drivers/link/nios_link.h"

#include "usecase/dump_service.h"


#define DEBUG_PRINT

#ifdef DEBUG_PRINT
    #define DEBUG_PRINT(...) serial_printf(__VA_ARGS__)
#else
    #define DEBUG_PRINT(...)
#endif

extern const uint8_t HDR_ABBA[2];
extern const uint8_t HDR_CDDC[2];
extern const uint8_t HDR_EFFE[2];
extern const uint8_t TRL_5354[2];
extern const uint8_t TRL_5556[2];
extern const uint8_t TRL_5758[2];
extern const uint8_t KVH_HEADER[4];
#define POLYNOMIAL_32 0x04C11DB7

// extern uint8_t g_wz_src;

// first order temperature compensation, one T
#define SF_TEMP_COMPENSATION_1ST_ORDER(temp, slope, offset) ((temp) * (slope) + (offset))

// first order temperature compensation, three T
#define BIAS_TEMP_COMPENSATION_1ST_ORDER_3T(temp, T1, T2, s1, o1, s2, o2, s3, o3) \
        (((temp) < (T1)) ? ((temp) * (s1) + (o1)) : \
        ((temp) < (T2)) ? ((temp) * (s2) + (o2)) : \
                        ((temp) * (s3) + (o3)))

/* ---------- Protocol condition values ----------
 * Keep aligned with readDataDynamic():
 *   1 -> AB BA ... 55 56  (DATA1_SIZE = 6)
 *   2 -> CD DC ... 57 58  (DATA2_SIZE = 13)
 *   3 -> EF FE ... 53 54  (DATA3_SIZE = 6)
 */
typedef enum {
  RX_CONDITION_INIT         = 0,
  RX_CONDITION_ABBA_5556    = 1,
  RX_CONDITION_CDDC_5758    = 2,
  RX_CONDITION_EFFE_5354    = 3,
  RX_CONDITION_BCCB_5152    = 4
} rx_condition_t;

/* ---------- MUX / State selections (adjust if needed) ---------- */
typedef enum {
  MUX_ESCAPE     = 0,
  MUX_PARAMETER  = 1,
  MUX_OUTPUT     = 2,
  MUX_DEFAULT    = 3
} mux_t;

typedef enum {
    SEL_IDLE = 0,
    SEL_RST = 1,
    SEL_FOG = 2,
    SEL_FOG_2 = 3,
    SEL_FOG_3 = 4,
    SEL_IMU = 5,
    SEL_AHRS = 6,
    SEL_HINS = 7,
    SEL_CV7 = 8
} select_fn_t;

typedef enum {
    MODE_RST = 0,
    MODE_FOG = 1,
    MODE_IMU = 2,
    MODE_AHRS = 3,
    MODE_HINS = 4,
    MODE_CV7 = 5
} output_mode_t;

typedef union
{
  float float_val;
  uint8_t bin_val[4];
  int32_t int_val;
}
my_float_t;

typedef union
{
  float float_val[3];
  uint8_t bin_val[12];
  int int_val[3];
}my_att_t;

/*** sensor data structure delaration */

typedef struct {
  my_float_t err; 
  my_float_t step;  
  my_float_t step_L;
  my_float_t step_H;
  my_float_t step_cnt;    
} fog_component_t;

typedef struct {
  fog_component_t fogx;
  fog_component_t fogy;
  fog_component_t fogz;
} fog_t;

typedef struct {
  my_float_t tempx;  
  my_float_t tempy; 
  my_float_t tempz; 
} temp_t;

typedef struct {
  my_float_t time;  
} my_time_t;

typedef struct {
  my_float_t ax;  
  my_float_t ay; 
  my_float_t az; 
  my_float_t temp;
} accl_t;

typedef struct {
  my_float_t gx;  
  my_float_t gy; 
  my_float_t gz; 
  my_float_t temp;
} m_gyro_t;

typedef struct {
  my_float_t  tow;  
  my_float_t  heading; 
  my_float_t  heading_unc; 
  uint8_t     fix_type;
  uint16_t    status_flag;
  uint16_t    valid_flag;
} hins_t;

typedef struct {
  my_float_t  Vin_mon;  
  my_float_t  Tact_mon; 
  my_float_t  pump_pd_mon; 
} hk_t;

typedef struct {
  uint8_t     timebase;
  uint8_t     reserved;
  uint64_t    nanosecs;
} timestamp_t;

typedef struct {
  timestamp_t   ts;
  uint8_t       Frame_id;
  my_float_t    Heading;
  my_float_t    Uncertainty;
  uint16_t      valid_flag;
} true_heading_t;

typedef struct {
  double      gps_tow;  // 來自 0xD3 的時間戳 (雙精度浮點數)
  float       heading_da;    // 來自 0x49: Dual Antenna Heading (rad)
  float       heading_unc;   // 來自 0x49: Heading Uncertainty (rad)
  uint8_t     fix_type;      // 0:None, 1:Float, 2:Fixed
  uint16_t    status_flag;   // bit 0: rcv_1, bit 1: rcv_2, bit 2: ant_offset
  uint16_t    valid_flag_da; // 0:Invalid, 1:Valid
  uint16_t    filter_state; // 1:Init, 2: vert_gyro, 3: ahrs, 4: full_nav
  uint16_t    dynamic_mode;  // 1: default
  uint16_t    status_flag_82;
  // ---- Aiding Measurement Summary (0x82, 0x46) ----
  float    aiding_tow;      // Last aiding TOW
  uint8_t  aiding_source;   // Source frame ID
  uint8_t  aiding_type;     // External measurement type
  uint8_t  aiding_indicator;// Status flags

  uint8_t     case_flag;

} hins_mip_data_t;

typedef struct 
{
  my_time_t time;
  fog_t fog;
  temp_t temp;
  accl_t accl;
  m_gyro_t m_gyro;
  hk_t hk;
  hins_mip_data_t hins;
  true_heading_t true_heading;
}my_sensor_t;

typedef struct {
  my_float_t x;
  my_float_t y;
  my_float_t z;
} calibrated_data_t;

/* ---------- Command control structure ---------- */
typedef struct
{
  rx_condition_t condition;  /* 0/1/2/3 per above */
  uint8_t  SN[13];           /* Up to 12 chars + NUL */
  uint8_t  complete;         /* 1 when a command parsed successfully */
  uint8_t  mux;              /* MUX_ESCAPE / MUX_OUTPUT / MUX_PARAMETER */
  uint8_t  select_fn;        /* SEL_IDLE or others you add later */
  uint8_t  ch;               /* channel */
  uint8_t  cmd;              /* command code */
  uint8_t  run;              /* optional run flag */
  int32_t  value;            /* 32-bit value, big-endian assembled */
  // ===== condition 4 (HINS/MIP) 專用 =====
  uint8_t*  hins_payload;       // points to raw bytes in rx buffer (&data[3])
  uint16_t  hins_payload_len;   // data[2]
} cmd_ctrl_t;

typedef enum {
  DISABLE = 0,
  ENABLE  = 1
} auto_run_mode_t;

/*** system control reset structure delaration */
typedef struct {
  // uint8_t status;
  auto_run_mode_t auto_run;
  uint8_t fn_mode;
} sys_ctrl_t;

/* ---------- API ---------- */
void get_uart_cmd(uint8_t* data, cmd_ctrl_t* rx);
void cmd_mux(cmd_ctrl_t* rx);

void update_parameter_container(const cmd_ctrl_t* rx, fog_parameter_t* fog_inst, uint8_t idx);

size_t read_json_object(Stream& s, char* out, size_t out_cap, uint32_t timeout_ms);
void dumpPkt(uint8_t *pkt, int len);
int update_raw_data(const uint8_t* pkt, my_sensor_t* out);
void sensor_data_cali(const my_sensor_t* raw, my_sensor_t* cali, fog_parameter_t* fog_parameter);
void pack_sensor_payload_from_cali(const my_sensor_t* cali, uint8_t* out);
void reset_FPGA_timer(void);
void set_wz_source(uint8_t src);





#endif /* COMMON_H */

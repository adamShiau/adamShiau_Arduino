#pragma once

#ifndef MCU_VERSION
#define MCU_VERSION "HINS_MCU_V3.41"
#endif

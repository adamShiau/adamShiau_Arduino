#pragma once

#include <Arduino.h>
// #include "../../domain/model/memory_manage.h"
// #include "output_mode_config.h"        // legacy fn_ptr
#include "../../domain/model/output_fn_t.h"  // new output_fn_t
#include "../../common.h"

int output_mode_setting(cmd_ctrl_t* rx, fn_ptr* output_fn, sys_ctrl_t* sys_ctrl);

// void clear_SEL_EN(cmd_ctrl_t*);


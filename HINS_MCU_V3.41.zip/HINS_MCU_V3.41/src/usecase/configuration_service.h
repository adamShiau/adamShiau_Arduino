#pragma once

#include <Arduino.h>
#include <stdint.h>

#include "../domain/model/memory_manage.h"  // fog_parameter_t
#include "../common.h"  

/**
 * @brief Apply all configuration items from parameter container.
 *
 * Intended usage (boot restore):
 *   boot_capture_all(&g_fog_params);
 *   apply_configuration_from_container(&g_fog_params);
 */
void apply_configuration_from_container(const fog_parameter_t* params);

void update_sys_ctrl_from_container(const fog_parameter_t* params, sys_ctrl_t* sys_ctrl);

/**
 * @brief Apply datarate index (0..4) to system.
 *
 * - Sends CMD_SYNC_CNT to FPGA (ch=6)
 * - Updates MCU local sampling rate (set_data_rate + ahrs_attitude.init)
 */
bool apply_datarate_index(uint8_t dr_index);

/**
 * @brief Apply baudrate index (0..4) to MCU output port.
 *
 * - Only affects MCU UART (output port)
 */
bool apply_baudrate_index(uint8_t br_index);

bool apply_attitude_init(uint8_t dr_index);

/**
 * @brief 從容器中提取 Rcs 矩陣並應用至 AHRS 演算法
 */
void apply_rcs_matrix_from_container(const fog_parameter_t* params);

void apply_is_NED_from_container(const fog_parameter_t* params);

bool apply_ASM330LHHX_Gyro_LPF1_from_container(const fog_parameter_t* params);

bool apply_ASM330LHHX_Accl_LPF2_from_container(const fog_parameter_t* params);

bool apply_gyroZ_source_from_container(const fog_parameter_t* params);

